# -*- coding: utf-8 -*-
"""
Created on Sun Nov 11 00:32:15 2018

@author: Siddhartha Banerjee
"""

#Read the data and divide it into training and testing:
 
import numpy as np
import pandas as pd
from sklearn import preprocessing
from sklearn.cross_validation import train_test_split
from sklearn.tree import DecisionTreeClassifier 
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import BernoulliNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn import metrics
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
from pandas import DataFrame as df
from sklearn.decomposition import FastICA, PCA



## set the seed...
seed = 110
np.random.seed(seed) ## set the seed to stop random behaviour.


#Set location of the input data 
Location = r'C:\BITS\Sem2\ML\ML_Assignment\InputData.xlsx'
# Split the data into columns and read
datainput = pd.read_excel(Location, names = ['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'a8','a9', 'a10', 'a11', 'a12', 'a13', 'a14', 'a15', 'a16','a17', 'a18', 'a19', 'a20', 'a21', 'a22', 'a23', 'a24', 'a25', 'a26','a27', 'a28', 'a29', 'a30','a31', 'a32', 'a33', 'a34', 'a35', 'a36','a37', 'a38', 'a39', 'a40','a41','a42'])

print("***********************************O R I G I N A L   D A T A ************************")
#Print before removing the outliers
print("Original data shape is ------------------------------>", datainput.shape)
print("The statistics of the data as provided is ------------------------------>")
print(datainput.describe())

print("***********************************O U T L I E R S  R E M O V A L *******************")
#Outlier Removal
#Dataset<(Q1−1.5∗IQR)|Dataset>(Q3+1.5∗IQR)Dataset<(Q1−1.5∗IQR)|Dataset>(Q3+1.5∗IQR)
first_quartile = datainput.quantile(0.25)
third_quartile = datainput.quantile(0.75)
IQR = third_quartile - first_quartile
## lets use the above formula to remove the outliers and filter the dataset..
clean_data = datainput[~((datainput < (first_quartile - 1.5 * IQR)) | (datainput > (third_quartile + 1.5 * IQR))).any(axis=1)]


#Outcome of the data
#y_value = clean_data['a42']
y_value = clean_data['a42']
#Set the outcome and dedlete it
#del clean_data['a42']
del clean_data['a42']

#temp_shape=clean_data.shape()
print("Data shape after removal of outliers is ------------------------------>", clean_data.shape)
temp_describe=clean_data.describe()
print("The statistics of the data after removal of outliers is ------------------------------>", temp_describe)


# Split data into Test & Training set where test data is 30% & raining data is 70%
x_train, x_test, y_train, y_test = train_test_split(clean_data, y_value, test_size = 0.3, random_state=seed)


#Scaling for featrure normalization for setting values between 0 & 1
scaling = preprocessing.MinMaxScaler(feature_range=(0, 1))


# Minmax scaling of training & test data
x_train_minmax=scaling.fit_transform(x_train)
x_test_minmax=scaling.fit_transform(x_test)



print('******************************** M I N   M A X   S C A L I N G *************')
# Check the split
print ("The data after split of Test & Training data is------------------------------>")
print(x_train_minmax.shape)
print(x_test_minmax.shape)

x_test_pca = x_test_minmax
x_train_pca = x_train_minmax


print("***************************** D E S C I S I O N T R E E ********************")
# Use Descision tree classifier on the training data===========================================
print('---------------------------------------------- ')
classify1 = DecisionTreeClassifier(random_state=seed)
#Train the model
classify1.fit(x_train_minmax, y_train)
# Use the model on the test data
y_predicted1 = classify1.predict(x_test_minmax)
print ("The accuracy score using the Decision Tree is ->" )
print (metrics.accuracy_score(y_test, y_predicted1))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted1))
print('Accuracy : ', accuracy_score(y_test, y_predicted1))
print('\nClassification Report \n', classification_report(y_test, y_predicted1))
print('---------------------------------------------- ')

print("************************* K N E A R E S T N E I G H B O U R **************")
# Next use KNearest Neighbours ============================================================
classify2 = KNeighborsClassifier()
#Train the model
classify2.fit(x_train_minmax, y_train)
# Use the model on the test data
y_predicted2 = classify2.predict(x_test_minmax)
print ("The accuracy score using the K Nereast Neighbour is ->" )
print (metrics.accuracy_score(y_test, y_predicted2))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted2))
print('Accuracy : ', accuracy_score(y_test, y_predicted2))
print('\nClassification Report \n', classification_report(y_test, y_predicted2))
print('---------------------------------------------- ')

print("************************* N A I V E B A Y E S **************************")
#Next use NaiveBayes Classifier =========================================================================
classify3 = BernoulliNB()
#Train the model
classify3.fit(x_train_minmax, y_train)
# Use the model on the test data
y_predicted3 = classify3.predict(x_test_minmax)
print ("The accuracy score using the Naive Bayes Classifier is ->" )
print (metrics.accuracy_score(y_test, y_predicted3))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted3))
print('Accuracy : ', accuracy_score(y_test, y_predicted3))
print('\nClassification Report \n', classification_report(y_test, y_predicted3))
print('---------------------------------------------- ')

print("************************* R A N D O M F O R E S T ***********************")
# Next use RandomForest Classifier ===========================================================
classify4 = RandomForestClassifier(random_state=seed)
#Train the model
classify4.fit(x_train_minmax, y_train)
# Use the model on the test data
y_predicted4 = classify4.predict(x_test_minmax)
print ("The accuracy score using the RandomForest is ->" )
print (metrics.accuracy_score(y_test, y_predicted4))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted4))
print('Accuracy : ', accuracy_score(y_test, y_predicted4))
print('\nClassification Report \n', classification_report(y_test, y_predicted4))
print('---------------------------------------------- ')



print("*********************************** S V M **********************************")
# Next use SVM===============================================================================
#classify5 = SVC()#kernel='poly', degree=8
classify5 = SVC(kernel='linear', degree=4, random_state=seed)
#Train the model
classify5.fit(x_train_minmax, y_train)
# Use the model on the test data
y_predicted5 = classify5.predict(x_test_minmax)
print ("The accuracy score using the SVM is ->" )
print (metrics.accuracy_score(y_test, y_predicted5))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted5))
print('Accuracy : ', accuracy_score(y_test, y_predicted5))
print('\nClassification Report \n', classification_report(y_test, y_predicted5))
print('---------------------------------------------- ')




print("********************* L O G I S T I C  R E G R E S S I O N ***************")

#Apply Logistic Regression to the Transformed Data
classify6 = LogisticRegression(solver = 'lbfgs')
#Train the model
classify6=classify6.fit(x_train_minmax, y_train)
# Use the model on the test data
y_predicted6 = classify6.predict(x_test_minmax)
print ("The accuracy score using the Logist Regression is ->" )
print (metrics.accuracy_score(y_test, y_predicted6))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted6))
print('Accuracy : ', accuracy_score(y_test, y_predicted6))
print('\nClassification Report \n', classification_report(y_test, y_predicted6 ))
print('---------------------------------------------- ')


print("********************* Applying PCA *********************")

# Next use PCA ===============================================================================
#Reference - https://towardsdatascience.com/pca-using-python-scikit-learn-e653f8989e60
# default solver is incredibly slow which is why it was changed to 'lbfgs'

for component in range(4, 20, 2):
    print('Number of Components : ', component)
    pca = PCA(n_components=component)
    pca.fit(x_train_minmax)
    print('Explained Variance Ratio : ', sum(pca.explained_variance_ratio_))


# Make an instance of the Model
pca = FastICA(n_components=20, random_state=seed)

#Fit the training data
pca.fit(x_train_minmax)

#transofrm the test & training data
x_train_pca = pca.transform(x_train_minmax)
x_test_pca = pca.transform(x_test_minmax)
#print the number of reduced attributes
print ("The data after PCA transformatio is------------------------------>")
print(x_train_pca.shape)
print(x_test_pca.shape)

print("**********************PCA + D E S C I S I O N T R E E ********************")
# Use Descision tree classifier on the training data===========================================
print('---------------------------------------------- ')
classify1 = DecisionTreeClassifier(random_state=seed)
#Train the model
classify1.fit(x_train_pca, y_train)
# Use the model on the test data
y_predicted1 = classify1.predict(x_test_pca)
print ("The accuracy score using the PCA+ Decision Tree is ->" )
print (metrics.accuracy_score(y_test, y_predicted1))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted1))
print('Accuracy : ', accuracy_score(y_test, y_predicted1))
print('\nClassification Report \n', classification_report(y_test, y_predicted1))
print('---------------------------------------------- ')

print("**************** PCA + K N E A R E S T N E I G H B O U R **************")
# Next use KNearest Neighbours ============================================================
classify2 = KNeighborsClassifier()
#Train the model
classify2.fit(x_train_pca, y_train)
# Use the model on the test data
y_predicted2 = classify2.predict(x_test_pca)
print ("The accuracy score using the PCA + K Nereast Neighbour is ->" )
print (metrics.accuracy_score(y_test, y_predicted2))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted2))
print('Accuracy : ', accuracy_score(y_test, y_predicted2))
print('\nClassification Report \n', classification_report(y_test, y_predicted2))
print('---------------------------------------------- ')

print("***************** PCA + N A I V E B A Y E S **************************")
#Next use NaiveBayes Classifier =========================================================================
classify3 = BernoulliNB()
#Train the model
classify3.fit(x_train_pca, y_train)
# Use the model on the test data
y_predicted3 = classify3.predict(x_test_pca)
print ("The accuracy score using the PCA + Naive Bayes Classifier is ->" )
print (metrics.accuracy_score(y_test, y_predicted3))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted3))
print('Accuracy : ', accuracy_score(y_test, y_predicted3))
print('\nClassification Report \n', classification_report(y_test, y_predicted3))
print('---------------------------------------------- ')

print("****************** PCA + R A N D O M F O R E S T************************")
# Next use RandomForest Classifier ===========================================================
classify4 = RandomForestClassifier(random_state=seed)
#Train the model
classify4.fit(x_train_pca, y_train)
# Use the model on the test data
y_predicted4 = classify4.predict(x_test_pca)
print ("The accuracy score using the PCA + RandomForest is ->" )
print (metrics.accuracy_score(y_test, y_predicted4))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted4))
print('Accuracy : ', accuracy_score(y_test, y_predicted4))
print('\nClassification Report \n', classification_report(y_test, y_predicted4))
print('---------------------------------------------- ')



print("***********************PCA + S V M **********************************")
# Next use SVM===============================================================================
#classify5 = SVC()#kernel='poly', degree=8
classify5 = SVC(kernel='linear', degree=4, random_state=seed)
#Train the model
classify5.fit(x_train_pca, y_train)
# Use the model on the test data
y_predicted5 = classify5.predict(x_test_pca)
print ("The accuracy score using the PCA + SVM is ->" )
print (metrics.accuracy_score(y_test, y_predicted5))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted5))
print('Accuracy : ', accuracy_score(y_test, y_predicted5))
print('\nClassification Report \n', classification_report(y_test, y_predicted5))
print('---------------------------------------------- ')




print("****************PCA +  L O G I S T I C  R E G R E S S I O N ***************")

#Apply Logistic Regression to the Transformed Data
classify6 = LogisticRegression(solver = 'lbfgs')
#Train the model
classify6=classify6.fit(x_train_pca, y_train)
# Use the model on the test data
y_predicted6 = classify6.predict(x_test_pca)
print ("The accuracy score using the PCA + Logist Regression is ->" )
print (metrics.accuracy_score(y_test, y_predicted6))
print('Confusion Matrix \n', confusion_matrix(y_test, y_predicted6))
print('Accuracy : ', accuracy_score(y_test, y_predicted6))
print('\nClassification Report \n', classification_report(y_test, y_predicted6 ))
print('---------------------------------------------- ')
