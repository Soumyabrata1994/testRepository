import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import metrics
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import BernoulliNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn import metrics

data = pd.read_csv('C:\\ML_Assignment_2nd_sem\\InputData.csv',header=None)
data.head(5)
data.isnull().sum()
data1 = data.drop(41,axis=1)
scaler = StandardScaler()
print(scaler.fit(data1))
data_scled = scaler.transform(data1)
data_scled = pd.DataFrame(data_scled)
data_scled.head(5)
X = data1
y = data[41]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)
logisticRegr = LogisticRegression()
logisticRegr.fit(X_train, y_train)
logisticRegr.predict(X_test)
predictions = logisticRegr.predict(X_test)
predictions
score = logisticRegr.score(X_test, y_test)
print(score)
conf_mat = metrics.confusion_matrix(y_test, predictions)
print(cm)
print("***************************** D E S C I S I O N T R E E ********************")


classify = DecisionTreeClassifier()
classify.fit(X_train,y_train)
classify.predict(X_test)
score = classify.score(X_test, y_test)
print(score)
conf_mat = metrics.confusion_matrix(y_test, predictions)
print(cm)
print("************************* K N E A R E S T N E I G H B O U R **************")
classify2 = KNeighborsClassifier()
classify.fit(X_train, y_train)
predictions = classify2.predict(X_test)
predictions
score = classify2.score(X_test, y_test)
print(score)
conf_mat = metrics.confusion_matrix(y_test, predictions)
print(conf_mat)

classify = BernoulliNB()
classify.fit(X_train, y_train)
predictions = classify.predict(X_test)
predictions
score = classify.score(X_test, y_test)
print(score)
conf_mat = metrics.confusion_matrix(y_test, predictions)
print(conf_mat)

classify = RandomForestClassifier(random_state=42)
classify.fit(X_train, y_train)
predictions = classify.predict(X_test)
predictions
score = classify.score(X_test, y_test)
print(score)
conf_mat = metrics.confusion_matrix(y_test, predictions)
print(conf_mat)


