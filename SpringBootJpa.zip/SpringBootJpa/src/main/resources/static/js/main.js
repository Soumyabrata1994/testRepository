$(document).ready(function () {

	
    $("#btnSubmit").click(function (event) {
    
    	var file = $("#file")[0].files[0].val;
    	var iSize = ($("#file")[0].files[0].size);
    	
    	if ( file ) {
            var get_ext = file.split('.');
            get_ext = get_ext.reverse();
            if ( $.inArray ( get_ext[0].toLowerCase(), exts ) > -1 ){
            	if(iSize < 60*1024*1024){
                    //stop submit the form, we will post it manually.
                    event.preventDefault();
                    fire_ajax_submit();
                	}else{
                		$("#result").text("Attachment size exceeds the allowable limit! (60MB)");
                		event.preventDefault();
                	}

            } else {
              alert( 'Invalid file!' );
            }
          }
    	
    });

});

function fire_ajax_submit() {

    // Get form
    var form = $('#fileUploadForm')[0];

    var data = new FormData(form);

    data.append("CustomField", "This is some extra data, testing");

    $("#btnSubmit").prop("disabled", true);

    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: "/api/upload/multi",
        data: data,
        //http://api.jquery.com/jQuery.ajax/
        //https://developer.mozilla.org/en-US/docs/Web/API/FormData/Using_FormData_Objects
        processData: false, //prevent jQuery from automatically transforming the data into a query string
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function (data) {

            $("#result").text(data);
            console.log("SUCCESS : ", data);
            $("#btnSubmit").prop("disabled", false);

        },
        error: function (e) {

            $("#result").text(e.responseText);
            console.log("ERROR : ", e);
            $("#btnSubmit").prop("disabled", false);

        }
    });

}