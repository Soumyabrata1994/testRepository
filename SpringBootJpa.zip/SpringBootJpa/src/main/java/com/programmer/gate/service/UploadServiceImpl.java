package com.programmer.gate.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.programmer.gate.model.UploadProperties;
import com.programmer.gate.repository.UploadRepository;
@Service
public class UploadServiceImpl implements UploadService {
    @Autowired
    private UploadRepository uploadRepository;
    
    public List<UploadProperties> getAllUploads(long uploadId) {
        return uploadRepository.findByUploadId(uploadId);
    }
    public void addNewUploads(UploadProperties upload) {
    	uploadRepository.save(upload);
    }
}