package com.programmer.gate.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="Upload_Details")
public class UploadProperties {
	
	@Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "upload_Sequence")
    @SequenceGenerator(name = "upload_Sequence", sequenceName = "UPLOAD_SEQ")
	private Long uploadId;
	@Column(name = "job_Id")
	private int jobId;
	@Column(name = "directory_Path")
	private String directoryPath;	
	@Column(name = "file_Name")
	private String fileName;	
	@Column(name = "job_Status")
	private Boolean jobStatus;
	@Column(name = "time_Of_job")
	private String timeOfjob;
	@Column(name = "vendor_Type")
	private String	vendorType ;
	@Column(name = "submitted_By")
	private String submittedBy;
	@Column(name = "file_Type")
	private String fileType;
	@Column(name = "time_Of_Job_Completed")
	private String timeOfJobCompleted;
	
    public UploadProperties() {
    }
    
	public UploadProperties(long uploadId, int jobId, String directoryPath, String fileName, Boolean jobStatus,
			String timeOfjob, String vendorType, String submittedBy, String fileType, String timeOfJobCompleted) {
		super();
		this.uploadId = uploadId;
		this.jobId = jobId;
		this.directoryPath = directoryPath;
		this.fileName = fileName;
		this.jobStatus = jobStatus;
		this.timeOfjob = timeOfjob;
		this.vendorType = vendorType;
		this.submittedBy = submittedBy;
		this.fileType = fileType;
		this.timeOfJobCompleted = timeOfJobCompleted;
	}

	public Long getUploadId() {
		return uploadId;
	}

	public void setUploadId(Long uploadId) {
		this.uploadId = uploadId;
	}

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public String getDirectoryPath() {
		return directoryPath;
	}

	public void setDirectoryPath(String directoryPath) {
		this.directoryPath = directoryPath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Boolean getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(Boolean jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getTimeOfjob() {
		return timeOfjob;
	}

	public void setTimeOfjob(String timeOfjob) {
		this.timeOfjob = timeOfjob;
	}

	public String getVendorType() {
		return vendorType;
	}

	public void setVendorType(String vendorType) {
		this.vendorType = vendorType;
	}

	public String getSubmittedBy() {
		return submittedBy;
	}

	public void setSubmittedBy(String submittedBy) {
		this.submittedBy = submittedBy;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getTimeOfJobCompleted() {
		return timeOfJobCompleted;
	}

	public void setTimeOfJobCompleted(String timeOfJobCompleted) {
		this.timeOfJobCompleted = timeOfJobCompleted;
	}

	@Override
	public String toString() {
		return "UploadProperties [uploadId=" + uploadId + ", jobId=" + jobId + ", directoryPath=" + directoryPath
				+ ", fileName=" + fileName + ", jobStatus=" + jobStatus + ", timeOfjob=" + timeOfjob + ", vendorType="
				+ vendorType + ", submittedBy=" + submittedBy + ", fileType=" + fileType + ", timeOfJobCompleted="
				+ timeOfJobCompleted + "]";
	}
    
}