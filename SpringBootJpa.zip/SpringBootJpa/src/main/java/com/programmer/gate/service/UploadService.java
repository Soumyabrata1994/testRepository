package com.programmer.gate.service;
import java.util.List;

import com.programmer.gate.model.UploadProperties;
public interface UploadService {
    public List<UploadProperties> getAllUploads(long uploadId);
    public void addNewUploads(UploadProperties upload);
}