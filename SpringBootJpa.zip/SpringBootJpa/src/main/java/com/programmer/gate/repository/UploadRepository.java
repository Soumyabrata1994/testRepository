package com.programmer.gate.repository;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.programmer.gate.model.UploadProperties;
@Repository
public interface UploadRepository extends CrudRepository<UploadProperties, Long> {
    List<UploadProperties> findByUploadId(long uploadId);
}