package com.programmer.gate;
import java.util.List;

import org.apache.coyote.http11.AbstractHttp11Protocol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.context.annotation.Bean;

import com.programmer.gate.model.UploadProperties;
import com.programmer.gate.service.UploadService;
@SpringBootApplication
public class Application implements CommandLineRunner{
	private int maxUploadSizeInMb = 60 * 1024 * 1024; // 10 MB
    @Autowired
    UploadService uploadService;
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
    @Override
    public void run(String... arg0) throws Exception {
        uploadService.addNewUploads(new UploadProperties());
        uploadService.addNewUploads(new UploadProperties());
        uploadService.addNewUploads(new UploadProperties());
        uploadService.addNewUploads(new UploadProperties());
        List<UploadProperties> uploads = uploadService.getAllUploads(50);
        for(UploadProperties upload : uploads)
        {
            System.out.println("Upload Details ==> " + upload);
        }
    }
  //Tomcat large file upload connection reset
    //http://www.mkyong.com/spring/spring-file-upload-and-connection-reset-issue/
    @Bean
    public TomcatEmbeddedServletContainerFactory tomcatEmbedded() {

        TomcatEmbeddedServletContainerFactory tomcat = new TomcatEmbeddedServletContainerFactory();

        tomcat.addConnectorCustomizers((TomcatConnectorCustomizer) connector -> {
            if ((connector.getProtocolHandler() instanceof AbstractHttp11Protocol<?>)) {
                //-1 means unlimited
                ((AbstractHttp11Protocol<?>) connector.getProtocolHandler()).setMaxSwallowSize(-1);
            }
        });

        return tomcat;

    }
}